package com.tandalong.tandalong_myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


    public class MainActivity extends AppCompatActivity {
        TextView helloworld;
        Button button;
        ImageView imageview;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            button = findViewById(R.id.button);
            helloworld = findViewById(R.id.helloworld);
            imageview = findViewById(R.id.imageView2);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    {
                        helloworld.setText("Hi Ibn! You're so cool!");
                    }
                }

            });

            imageview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    {
                            helloworld.setText("hi it's me kanye, wsg fam");
                    }
                }

            });
        }

        ;
    }

